package com.example.ui

import androidx.lifecycle.ViewModel
import com.example.data.SampleData
import com.example.model.ComboDeal
import com.example.model.ContactCategory
import com.example.model.DailyTask
import com.example.model.DietaryPreference
import com.example.model.NeedItem
import com.example.model.NeighborhoodContact
import com.example.model.ProductCategory
import com.example.model.SmartSuggestion
import com.example.model.Store
import com.example.model.StoreComparisonResult
import com.example.model.StoreNews
import com.example.model.StoreProduct
import com.example.model.TaskCategory
import com.example.model.TransactionType
import com.example.model.TripRoute
import com.example.model.UserProfile
import com.example.model.UserWallet
import com.example.model.WalletTransaction
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

enum class StoreScheduleFilter(val label: String, val iconDescription: String) {
    TODOS("Todos", "Todos los comercios"),
    ABIERTOS_AHORA("Abiertos Ahora 🟢", "Comercios con atención en este momento"),
    FARMACIAS_TURNO("Farmacias de Turno 💊", "Guardia de 24hs y urgencias médicas"),
    TURNO_24HS("24 Horas / Guardia 🌙", "Atención continua día y noche"),
    FERIADOS("Abren Feriados 📅", "Atención en días no laborables")
}

sealed class Screen(val title: String) {
    object DailyHub : Screen("Tu Día")
    object SmartList : Screen("Mi Lista")
    object StoresList : Screen("Comercios")
    object Comparison : Screen("Comparador")
    object StoreDetail : Screen("Detalle del Local")
    object InteractiveRoute : Screen("Ruta Interactiva")
    object Wallet : Screen("Billetera OmniPay")
    object Contacts : Screen("Remises & Servicios")
    object UserProfile : Screen("Mi Cuenta & Ajustes")
    object MerchantHub : Screen("Panel de Comercio")
    object TripPlanner : Screen("Buscador de Viaje")
}

class MainViewModel : ViewModel() {

    private val _currentScreen = MutableStateFlow<Screen>(Screen.DailyHub)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _tasks = MutableStateFlow<List<DailyTask>>(SampleData.initialTasks)
    val tasks: StateFlow<List<DailyTask>> = _tasks.asStateFlow()

    private val _needs = MutableStateFlow<List<NeedItem>>(SampleData.initialNeeds)
    val needs: StateFlow<List<NeedItem>> = _needs.asStateFlow()

    private val _stores = MutableStateFlow<List<Store>>(SampleData.sampleStores)
    val stores: StateFlow<List<Store>> = _stores.asStateFlow()

    private val _selectedStore = MutableStateFlow<Store?>(SampleData.sampleStores.first())
    val selectedStore: StateFlow<Store?> = _selectedStore.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<ProductCategory?>(null)
    val selectedCategoryFilter: StateFlow<ProductCategory?> = _selectedCategoryFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Filtros de Horarios y Disponibilidad
    private val _scheduleFilter = MutableStateFlow(StoreScheduleFilter.TODOS)
    val scheduleFilter: StateFlow<StoreScheduleFilter> = _scheduleFilter.asStateFlow()

    // Simulación de Horario / Feriado para ver qué comercios abren en horas inusuales
    private val _simulatedHour = MutableStateFlow(14)
    val simulatedHour: StateFlow<Int> = _simulatedHour.asStateFlow()

    private val _isSimulatedHoliday = MutableStateFlow(false)
    val isSimulatedHoliday: StateFlow<Boolean> = _isSimulatedHoliday.asStateFlow()

    // Billetera Virtual y Pagos
    private val _wallet = MutableStateFlow(UserWallet())
    val wallet: StateFlow<UserWallet> = _wallet.asStateFlow()

    // Contactos y Remises Barriales
    private val _contacts = MutableStateFlow<List<NeighborhoodContact>>(SampleData.sampleContacts)
    val contacts: StateFlow<List<NeighborhoodContact>> = _contacts.asStateFlow()

    // Sugerencias Inteligentes
    private val _suggestions = MutableStateFlow<List<SmartSuggestion>>(SampleData.sampleSuggestions)
    val suggestions: StateFlow<List<SmartSuggestion>> = _suggestions.asStateFlow()

    // Perfil de Usuario y Ajustes
    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    // Modo Negocio / Comerciante (Mi Comercio Administrado)
    private val _managedStore = MutableStateFlow(SampleData.sampleStores.first())
    val managedStore: StateFlow<Store> = _managedStore.asStateFlow()

    // Muro de Noticias Barriales
    private val _storeNews = MutableStateFlow<List<StoreNews>>(SampleData.sampleNews)
    val storeNews: StateFlow<List<StoreNews>> = _storeNews.asStateFlow()

    // Buscador de Viajes y Recorridos
    private val _tripOrigin = MutableStateFlow("Supermercado San Martín")
    val tripOrigin: StateFlow<String> = _tripOrigin.asStateFlow()

    private val _tripDestination = MutableStateFlow("El Obelisco (Centro)")
    val tripDestination: StateFlow<String> = _tripDestination.asStateFlow()

    private val _currentTrip = MutableStateFlow(SampleData.calculateTrip(_tripOrigin.value, _tripDestination.value))
    val currentTrip: StateFlow<TripRoute> = _currentTrip.asStateFlow()

    // Alertas Meteorológicas & Catástrofes
    private val _weatherAlerts = MutableStateFlow(SampleData.sampleWeatherAlerts)
    val weatherAlerts: StateFlow<List<com.example.model.WeatherAlert>> = _weatherAlerts.asStateFlow()

    // Resumen Matutino de Despertar (Morning Briefing)
    private val _morningBriefing = MutableStateFlow(SampleData.sampleMorningBriefing)
    val morningBriefing: StateFlow<com.example.model.MorningBriefing> = _morningBriefing.asStateFlow()

    // Comprobantes Digitales y Facturas
    private val _receipts = MutableStateFlow(SampleData.sampleReceipts)
    val receipts: StateFlow<List<com.example.model.DigitalReceipt>> = _receipts.asStateFlow()

    // Atracciones Turísticas Cercanas (Modo Viajero)
    private val _touristAttractions = MutableStateFlow(SampleData.sampleTouristAttractions)
    val touristAttractions: StateFlow<List<com.example.model.TouristAttraction>> = _touristAttractions.asStateFlow()

    // Botón flotante tipo notificación para lista de compras
    private val _isFloatingShoppingPillVisible = MutableStateFlow(true)
    val isFloatingShoppingPillVisible: StateFlow<Boolean> = _isFloatingShoppingPillVisible.asStateFlow()

    // Punto de interés interactivo seleccionado en el camino
    private val _selectedWaypointLandmark = MutableStateFlow<String?>(null)
    val selectedWaypointLandmark: StateFlow<String?> = _selectedWaypointLandmark.asStateFlow()

    val comparisons: StateFlow<List<StoreComparisonResult>>
        get() {
            val res = SampleData.calculateComparison(_stores.value, _needs.value)
            return MutableStateFlow(res).asStateFlow()
        }

    fun toggleFloatingShoppingPill(visible: Boolean) {
        _isFloatingShoppingPillVisible.value = visible
    }

    fun selectWaypointLandmark(name: String?) {
        _selectedWaypointLandmark.value = name
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun selectStoreAndOpenDetail(store: Store) {
        _selectedStore.value = store
        _currentScreen.value = Screen.StoreDetail
    }

    fun selectStoreAndOpenRoute(store: Store) {
        _selectedStore.value = store
        _currentScreen.value = Screen.InteractiveRoute
    }

    fun selectStoreAndPlanTripFrom(store: Store) {
        _tripOrigin.value = store.name
        _currentTrip.value = SampleData.calculateTrip(store.name, _tripDestination.value)
        _currentScreen.value = Screen.TripPlanner
    }

    fun searchTrip(origin: String, destination: String) {
        _tripOrigin.value = origin
        _tripDestination.value = destination
        _currentTrip.value = SampleData.calculateTrip(origin, destination)
    }

    fun toggleTask(taskId: String) {
        _tasks.value = _tasks.value.map {
            if (it.id == taskId) it.copy(isCompleted = !it.isCompleted) else it
        }
    }

    fun addTask(title: String, category: TaskCategory, timeTag: String) {
        val newTask = DailyTask(
            id = UUID.randomUUID().toString(),
            title = title,
            category = category,
            isCompleted = false,
            timeTag = timeTag.ifBlank { "09:00" }
        )
        _tasks.value = listOf(newTask) + _tasks.value
    }

    fun toggleNeed(needId: String) {
        _needs.value = _needs.value.map {
            if (it.id == needId) it.copy(isChecked = !it.isChecked) else it
        }
    }

    fun addNeed(name: String, category: ProductCategory, quantity: Int, unit: String) {
        val newNeed = NeedItem(
            id = UUID.randomUUID().toString(),
            name = name,
            category = category,
            quantity = quantity,
            unit = unit,
            isChecked = false
        )
        _needs.value = _needs.value + newNeed
    }

    fun deleteNeed(needId: String) {
        _needs.value = _needs.value.filter { it.id != needId }
    }

    fun addSuggestionToNeeds(suggestion: SmartSuggestion) {
        addNeed(suggestion.productName, suggestion.category, 1, "unid.")
        _suggestions.value = _suggestions.value.filter { it.id != suggestion.id }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: ProductCategory?) {
        _selectedCategoryFilter.value = category
    }

    // Funciones de Billetera Virtual (OmniPay)
    fun payWithWallet(storeName: String, amount: Double, cashbackPercent: Double = 5.0): Boolean {
        val currentBalance = _wallet.value.balance
        if (currentBalance < amount) return false

        val cashbackAmount = amount * (cashbackPercent / 100.0)
        val newBalance = currentBalance - amount + cashbackAmount

        val newTransactions = listOf(
            WalletTransaction(
                id = UUID.randomUUID().toString(),
                title = "Pago con QR en $storeName",
                storeOrEntityName = storeName,
                amount = -amount,
                type = TransactionType.COMPRA_LOCAL,
                dateText = "Recién",
                cashbackEarned = cashbackAmount
            ),
            WalletTransaction(
                id = UUID.randomUUID().toString(),
                title = "Reintegro Barrial ($cashbackPercent%)",
                storeOrEntityName = "OmniPay Cashback",
                amount = cashbackAmount,
                type = TransactionType.REINTEGRO_CASHBACK,
                dateText = "Recién"
            )
        ) + _wallet.value.transactions

        _wallet.value = _wallet.value.copy(
            balance = newBalance,
            totalCashbackEarned = _wallet.value.totalCashbackEarned + cashbackAmount,
            transactions = newTransactions
        )

        // Generación automática de comprobante fiscal digital
        val ticketNum = "T-" + (1000..9999).random() + "-" + (1000000..9999999).random()
        val newReceipt = com.example.model.DigitalReceipt(
            id = UUID.randomUUID().toString(),
            receiptNumber = ticketNum,
            storeName = storeName,
            dateText = "Hoy, " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date()) + " hs",
            items = listOf(
                com.example.model.ReceiptItem("Compra en comercio / Pago QR", 1, amount, amount)
            ),
            subtotal = amount,
            discountApplied = cashbackAmount,
            total = amount - cashbackAmount,
            paymentMethod = "OmniPay QR (5% Cashback Acreditado)",
            qrVerificationCode = "OMNI-VALID-" + (10000..99999).random()
        )
        _receipts.value = listOf(newReceipt) + _receipts.value

        return true
    }

    fun addStopToTrip(stopName: String, extraDistanceKm: Double = 1.2) {
        val current = _currentTrip.value
        val newDistance = current.distanceKm + extraDistanceKm
        val newWalking = (newDistance * 14).toInt()
        val newDriving = maxOf(4, (newDistance * 3.2).toInt())
        val newTransit = maxOf(8, (newDistance * 4.5).toInt())
        val newRemisCost = 1200.0 + (newDistance * 480.0)

        val newStep = com.example.model.TripStep(
            instruction = "Parada intermedia: $stopName",
            distanceText = "+${String.format("%.1f", extraDistanceKm)} km",
            subtext = "Parada agregada a tu recorrido personalizado"
        )

        val updatedSteps = current.steps.toMutableList()
        val insertIndex = if (updatedSteps.size > 1) updatedSteps.size - 1 else updatedSteps.size
        updatedSteps.add(insertIndex, newStep)

        _currentTrip.value = current.copy(
            distanceKm = newDistance,
            walkingMinutes = newWalking,
            drivingMinutes = newDriving,
            transitMinutes = newTransit,
            estimatedRemisCost = newRemisCost,
            steps = updatedSteps,
            landmarksOnRoute = listOf("⭐ Parada: $stopName") + current.landmarksOnRoute
        )
    }

    fun addFunds(amount: Double) {
        val newBalance = _wallet.value.balance + amount
        val newTx = WalletTransaction(
            id = UUID.randomUUID().toString(),
            title = "Carga de Saldo",
            storeOrEntityName = "Transferencia Bancaria",
            amount = amount,
            type = TransactionType.CARGA_SALDO,
            dateText = "Recién"
        )
        _wallet.value = _wallet.value.copy(
            balance = newBalance,
            transactions = listOf(newTx) + _wallet.value.transactions
        )
    }

    // Funciones de Contactos
    fun toggleContactFavorite(contactId: String) {
        _contacts.value = _contacts.value.map {
            if (it.id == contactId) it.copy(isFavorite = !it.isFavorite) else it
        }
    }

    fun addCustomContact(name: String, category: ContactCategory, phone: String, address: String) {
        val newContact = NeighborhoodContact(
            id = UUID.randomUUID().toString(),
            name = name,
            category = category,
            phoneNumber = phone,
            statusText = "Agendado por ti",
            rating = 5.0f,
            address = address.ifBlank { null },
            isFavorite = true
        )
        _contacts.value = listOf(newContact) + _contacts.value
    }

    // Funciones de Ajustes de Usuario
    fun updateSearchRadius(meters: Int) {
        _userProfile.value = _userProfile.value.copy(searchRadiusMeters = meters)
    }

    fun updateDietaryPreference(pref: DietaryPreference) {
        _userProfile.value = _userProfile.value.copy(dietaryPreference = pref)
    }

    fun toggleMorningDigest(enabled: Boolean) {
        _userProfile.value = _userProfile.value.copy(morningDigestEnabled = enabled)
    }

    fun toggleOnRouteAlerts(enabled: Boolean) {
        _userProfile.value = _userProfile.value.copy(onRouteAlertsEnabled = enabled)
    }

    // Funciones de Panel de Comercio (Merchant Hub)
    fun toggleStoreOpenStatus() {
        val current = _managedStore.value
        val updated = current.copy(isOpen = !current.isOpen)
        _managedStore.value = updated
        _stores.value = _stores.value.map { if (it.id == updated.id) updated else it }
    }

    fun addProductToManagedStore(name: String, category: ProductCategory, price: Double, originalPrice: Double?) {
        val current = _managedStore.value
        val newProd = StoreProduct(
            id = "prod_${UUID.randomUUID().toString().take(6)}",
            name = name,
            category = category,
            price = price,
            originalPrice = originalPrice,
            inStock = true
        )
        val updated = current.copy(inventory = listOf(newProd) + current.inventory)
        _managedStore.value = updated
        _stores.value = _stores.value.map { if (it.id == updated.id) updated else it }
    }

    fun addComboToManagedStore(title: String, description: String, discountBadge: String) {
        val current = _managedStore.value
        val newCombo = ComboDeal(title, description, discountBadge)
        val updated = current.copy(comboDeals = listOf(newCombo) + current.comboDeals)
        _managedStore.value = updated
        _stores.value = _stores.value.map { if (it.id == updated.id) updated else it }
    }

    fun updateDiscountThreshold(threshold: Double, percent: Int) {
        val current = _managedStore.value
        val updated = current.copy(
            minSpendDiscountThreshold = threshold,
            minSpendDiscountPercent = percent,
            specialOfferText = "$percent% de reintegro en canasta total superando los $${String.format("%,.0f", threshold)}"
        )
        _managedStore.value = updated
        _stores.value = _stores.value.map { if (it.id == updated.id) updated else it }
    }

    fun publishStoreNews(title: String, content: String, badge: String) {
        val current = _managedStore.value
        val newNews = StoreNews(
            id = UUID.randomUUID().toString(),
            storeId = current.id,
            storeName = current.name,
            title = title,
            content = content,
            timeAgoText = "Recién publicado",
            badge = badge.ifBlank { "Novedad Flash 🔥" }
        )
        _storeNews.value = listOf(newNews) + _storeNews.value
    }

    // Funciones de Configuración de Horarios & Guardia
    fun setScheduleFilter(filter: StoreScheduleFilter) {
        _scheduleFilter.value = filter
    }

    fun setSimulatedHour(hour: Int) {
        _simulatedHour.value = hour.coerceIn(0, 23)
    }

    fun toggleSimulatedHoliday() {
        _isSimulatedHoliday.value = !_isSimulatedHoliday.value
    }

    fun updateManagedStoreSchedule(
        openTime: String,
        closeTime: String,
        weekendHoursText: String,
        is24Hours: Boolean,
        isOnDuty: Boolean,
        openOnHolidays: Boolean,
        scheduleNotes: String,
        isOpenNow: Boolean
    ) {
        val current = _managedStore.value
        val hoursDisplay = when {
            isOnDuty -> "DE TURNO 24HS • Guardia Activa Nocturna y Feriados"
            is24Hours -> "Abierto 24 horas continuas • Todos los días"
            else -> "Abierto de $openTime a $closeTime hs"
        }
        val updated = current.copy(
            openTime = openTime,
            closeTime = closeTime,
            weekendHoursText = weekendHoursText,
            is24Hours = is24Hours,
            isOnDuty = isOnDuty,
            openOnHolidays = openOnHolidays,
            scheduleNotes = scheduleNotes,
            isOpen = isOpenNow,
            hoursText = hoursDisplay
        )
        _managedStore.value = updated
        _stores.value = _stores.value.map { if (it.id == updated.id) updated else it }
    }
}
